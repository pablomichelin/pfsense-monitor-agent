<?php

require_once("guiconfig.inc");
require_once("/usr/local/pkg/systemup_monitor.inc");

systemup_monitor_setup_package_tabs('config');

include("head.inc");
?>
<body>
<?php include("fbegin.inc"); ?>
<?php if (isset($tab_array) && function_exists('display_top_tabs')): ?>
<?php foreach ($tab_array as $tab): ?>
<?php display_top_tabs($tab); ?>
<?php endforeach; ?>
<?php endif; ?>

<section class="panel panel-default">
  <div class="panel-heading">
    <h2 class="panel-title">Configuracao do agente</h2>
  </div>
  <div class="panel-body">
    <p class="text-muted" style="margin: 0 0 1em 0; font-size: 0.9rem; line-height: 1.5;">
      Campos do controlador, identidade do node e servicos monitorados. Use o botao abaixo para alterar URL, node UID, cliente, intervalo e servicos; salve no formulario para aplicar.
    </p>
    <div class="form-group" style="margin-top: 1.25rem; margin-bottom: 0;">
      <a href="pkg_edit.php?xml=systemup_monitor.xml&amp;id=0" class="btn btn-primary" target="_blank" rel="noopener">
        <i class="fa-solid fa-pen-to-square icon-embed-btn"></i>
        Editar configuracao
      </a>
    </div>
    <p class="help-block" style="margin-top: 1rem; margin-bottom: 0; font-size: 0.85rem; color: #8a8a8a;">
      O formulario abre em nova aba. Apos salvar, feche a aba e esta pagina continua aqui; ou use a aba <strong>Configuracao</strong> acima para recarregar.
    </p>
  </div>
</section>
<?php include("foot.inc"); ?>
</body>
</html>
