#!/usr/local/bin/php
<?php
/**
 * Gestao de usuarios locais pfSense via auth.inc (disable/delete).
 * Uso: manage_local_user.php <disable|delete> <payload_file.json>
 * Payload: {"pfsense_username":"..."} — nunca logar senha.
 */

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "CLI only\n");
    exit(1);
}

$action = $argv[1] ?? '';
$payloadFile = $argv[2] ?? '';

if (!in_array($action, ['disable', 'delete'], true)) {
    fwrite(STDERR, "invalid action\n");
    exit(1);
}

if ($payloadFile === '' || !is_readable($payloadFile)) {
    fwrite(STDERR, "payload file missing\n");
    exit(1);
}

$rawPayload = file_get_contents($payloadFile);
$payload = json_decode($rawPayload !== false ? $rawPayload : '', true);
if (!is_array($payload)) {
    fwrite(STDERR, "invalid payload json\n");
    exit(1);
}

$username = '';
if (isset($payload['pfsense_username'])) {
    $username = strtolower(trim((string) $payload['pfsense_username']));
} elseif (isset($payload['username'])) {
    $username = strtolower(trim((string) $payload['username']));
}

if ($username === '' || !preg_match('/^[a-z][a-z0-9._-]{2,31}$/', $username)) {
    emit_result(false, 'invalid pfsense_username');
    exit(1);
}

if (in_array($username, ['admin', 'root'], true)) {
    emit_result(false, 'reserved username');
    exit(1);
}

require_once('/etc/inc/config.inc');
require_once('/etc/inc/auth.inc');

if (!function_exists('getUserEntry') || !function_exists('local_user_set') || !function_exists('local_user_del')) {
    emit_result(false, 'auth.inc helpers unavailable');
    exit(1);
}

$resolved = resolve_local_user_entry($username);
if ($resolved === null) {
    emit_result(false, 'user not found');
    exit(1);
}

$userIndex = $resolved['index'];
$user = $resolved['user'];
$canonicalName = trim((string) ($user['name'] ?? $username));

$scope = trim((string) ($user['scope'] ?? ''));
$uid = isset($user['uid']) ? (int) $user['uid'] : null;
if ($scope === 'system' || $uid === 0) {
    emit_result(false, 'cannot modify system account');
    exit(1);
}

try {
    if ($action === 'disable') {
        if (!empty($user['disabled'])) {
            emit_result(true, 'already disabled', [
                'username' => $canonicalName,
                'action' => 'disable',
            ]);
            exit(0);
        }

        $user['disabled'] = true;
        if (function_exists('config_set_path')) {
            config_set_path("system/user/{$userIndex}", $user);
        } else {
            $allUsers = config_get_path('system/user');
            if (!is_array($allUsers) || !isset($allUsers[$userIndex])) {
                emit_result(false, 'user index not found');
                exit(1);
            }
            $allUsers[$userIndex]['disabled'] = true;
            config_set_path('system/user', $allUsers);
        }

        local_user_set($user);
        write_config(sprintf('systemup-monitor: disable local user %s', $canonicalName));
        emit_result(true, 'disabled', [
            'username' => $canonicalName,
            'action' => 'disable',
        ]);
        exit(0);
    }

    // delete
    $usersPath = 'system/user';
    $allUsers = config_get_path($usersPath);
    if (!is_array($allUsers) || !isset($allUsers[$userIndex])) {
        emit_result(false, 'user index not found');
        exit(1);
    }

    $targetUser = $allUsers[$userIndex];
    local_user_del($targetUser);
    unset($allUsers[$userIndex]);
    $allUsers = array_values($allUsers);
    config_set_path($usersPath, $allUsers);
    write_config(sprintf('systemup-monitor: delete local user %s', $canonicalName));
    emit_result(true, 'deleted', [
        'username' => $canonicalName,
        'action' => 'delete',
    ]);
    exit(0);
} catch (Throwable $exception) {
    emit_result(false, 'operation failed');
    exit(1);
}

/**
 * @return array{index:int,user:array<string,mixed>}|null
 */
function resolve_local_user_entry(string $username): ?array
{
    $userEntry = getUserEntry($username);
    if (is_array($userEntry) && isset($userEntry['item']) && is_array($userEntry['item'])) {
        $index = isset($userEntry['idx']) ? (int) $userEntry['idx'] : null;
        if ($index === null) {
            $index = find_user_index_by_name($username, (string) ($userEntry['item']['name'] ?? ''));
        }
        if ($index === null) {
            return null;
        }

        return [
            'index' => $index,
            'user' => $userEntry['item'],
        ];
    }

    if (is_array($userEntry) && $userEntry !== []) {
        $index = find_user_index_by_name($username, (string) ($userEntry['name'] ?? ''));
        if ($index === null) {
            return null;
        }

        return [
            'index' => $index,
            'user' => $userEntry,
        ];
    }

    return find_user_entry_case_insensitive($username);
}

/**
 * @return array{index:int,user:array<string,mixed>}|null
 */
function find_user_entry_case_insensitive(string $username): ?array
{
    $allUsers = config_get_path('system/user');
    if (!is_array($allUsers)) {
        return null;
    }

    foreach ($allUsers as $index => $candidate) {
        if (!is_array($candidate)) {
            continue;
        }
        $candidateName = strtolower(trim((string) ($candidate['name'] ?? '')));
        if ($candidateName === $username) {
            return [
                'index' => (int) $index,
                'user' => $candidate,
            ];
        }
    }

    return null;
}

function find_user_index_by_name(string $username, string $canonicalName = ''): ?int
{
    $allUsers = config_get_path('system/user');
    if (!is_array($allUsers)) {
        return null;
    }

    foreach ($allUsers as $index => $candidate) {
        if (!is_array($candidate)) {
            continue;
        }
        $candidateName = strtolower(trim((string) ($candidate['name'] ?? '')));
        if ($candidateName === $username) {
            return (int) $index;
        }
        if ($canonicalName !== '' && trim((string) ($candidate['name'] ?? '')) === $canonicalName) {
            return (int) $index;
        }
    }

    return null;
}

/**
 * @param array<string, mixed> $extra
 */
function emit_result(bool $ok, string $message, array $extra = []): void
{
    $output = array_merge(
        [
            'ok' => $ok,
            'message' => $message,
        ],
        $extra,
    );
    echo json_encode($output, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n";
}
