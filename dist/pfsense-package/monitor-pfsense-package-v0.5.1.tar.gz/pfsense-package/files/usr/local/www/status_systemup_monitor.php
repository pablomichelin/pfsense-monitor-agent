<?php

require_once("guiconfig.inc");
require_once("/usr/local/pkg/systemup_monitor.inc");

systemup_monitor_setup_package_tabs('diagnostico');

$pkg = systemup_monitor_read_config();
$commands = systemup_monitor_local_commands();
$secret_masked = systemup_monitor_secret_display_label($pkg);
$runtime = systemup_monitor_runtime_summary();
$selected_services = systemup_monitor_selected_service_labels($pkg);
include("head.inc");
?>
<?php if (isset($tab_array) && function_exists('display_top_tabs')): ?>
<?php foreach ($tab_array as $tab): ?>
<?php display_top_tabs($tab); ?>
<?php endforeach; ?>
<?php endif; ?>

<?php if (!empty($savemsg)): ?>
<div class="alert alert-info"><?=htmlspecialchars($savemsg)?></div>
<?php endif; ?>

<section class="panel panel-default">
  <div class="panel-heading">
    <h2 class="panel-title">SystemUp Monitor local diagnostics</h2>
  </div>
  <div class="panel-body">
    <table class="table table-striped table-condensed">
      <tbody>
        <tr>
          <th>Enabled</th>
          <td><?=htmlspecialchars($pkg['enabled'] == 'on' ? 'yes' : 'no')?></td>
        </tr>
        <tr>
          <th>Controller URL</th>
          <td><?=htmlspecialchars($pkg['controller_url'])?></td>
        </tr>
        <tr>
          <th>Node UID</th>
          <td><?=htmlspecialchars($pkg['node_uid'])?></td>
        </tr>
        <tr>
          <th>Customer code</th>
          <td><?=htmlspecialchars($pkg['customer_code'])?></td>
        </tr>
        <tr>
          <th>Heartbeat interval</th>
          <td><?=htmlspecialchars($pkg['interval_seconds'])?>s</td>
        </tr>
        <tr>
          <th>Heartbeat mode</th>
          <td><?=htmlspecialchars($runtime['heartbeat_mode'])?></td>
        </tr>
        <tr>
          <th>Versão do agente</th>
          <td><?=htmlspecialchars(defined('SYSTEMUP_MONITOR_AGENT_VERSION') ? SYSTEMUP_MONITOR_AGENT_VERSION : '0.2.0')?></td>
        </tr>
        <tr>
          <th>Selected services</th>
          <td><?=htmlspecialchars(empty($selected_services) ? 'none' : implode(', ', $selected_services))?></td>
        </tr>
        <tr>
          <th>Node secret</th>
          <td><?=htmlspecialchars($secret_masked)?></td>
        </tr>
        <tr>
          <th>Runtime enabled</th>
          <td><?=htmlspecialchars($runtime['enabled'] ? 'yes' : 'no')?></td>
        </tr>
        <tr>
          <th>Runtime config ready</th>
          <td><?=htmlspecialchars($runtime['config_ready'] ? 'yes' : 'no')?></td>
        </tr>
        <tr>
          <th>Runtime config file</th>
          <td><?=htmlspecialchars($runtime['config_file'])?><?= $runtime['config_exists'] ? ' (present)' : ' (missing)' ?></td>
        </tr>
        <tr>
          <th>Service status</th>
          <td><?=htmlspecialchars($runtime['service_status'])?></td>
        </tr>
        <?php if (!empty($runtime['last_heartbeat_error'])): ?>
        <tr>
          <th>Last heartbeat error</th>
          <td>
            <?php
            $hbErr = $runtime['last_heartbeat_error'];
            $hbParts = array();
            if (!empty($hbErr['error_class'])) {
                $hbParts[] = 'class=' . $hbErr['error_class'];
            }
            if (!empty($hbErr['http_code'])) {
                $hbParts[] = 'HTTP ' . (int) $hbErr['http_code'];
            }
            if (!empty($hbErr['recorded_at'])) {
                $hbParts[] = 'at ' . $hbErr['recorded_at'];
            }
            echo htmlspecialchars(implode(', ', $hbParts));
            if (!empty($hbErr['body_excerpt'])) {
                echo '<br><span class="text-muted">' . htmlspecialchars($hbErr['body_excerpt']) . '</span>';
            }
            ?>
          </td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>

    <?php if (!$runtime['config_ready']): ?>
    <div class="alert alert-warning" role="alert">
      Faltam campos obrigatorios para gerar o runtime do agente:
      <?=htmlspecialchars(implode(', ', $runtime['missing_fields']))?>
    </div>
    <?php endif; ?>

    <div style="margin-top: 1rem; padding-left: 1rem; padding-right: 1rem;">
      <h3 style="margin-top: 1.25rem; margin-bottom: 0.5rem;">Runtime paths</h3>
      <pre style="margin-top: 0.5rem; margin-bottom: 0; padding: 0.75rem;"><?php
echo htmlspecialchars("Agent: " . $runtime['agent_bin'] . "\n");
echo htmlspecialchars("Loop: " . $runtime['loop_bin'] . "\n");
echo htmlspecialchars("RC: " . $runtime['rc_script'] . "\n");
echo htmlspecialchars("Log: " . $runtime['log_file'] . "\n");
if (!empty($runtime['service_detail'])) {
    echo "\n" . htmlspecialchars($runtime['service_detail']);
}
?></pre>

      <h3 style="margin-top: 1.25rem; margin-bottom: 0.5rem;">Operational commands</h3>
      <pre style="margin-top: 0.5rem; margin-bottom: 1.25rem; padding: 0.75rem;"><?php foreach ($commands as $command) { echo htmlspecialchars($command) . "\n"; } ?></pre>
    </div>
  </div>
</section>
<?php include("foot.inc"); ?>
