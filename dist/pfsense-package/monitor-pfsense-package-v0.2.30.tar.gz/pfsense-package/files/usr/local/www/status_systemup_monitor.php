<?php

require_once("guiconfig.inc");
require_once("/usr/local/pkg/systemup_monitor.inc");

systemup_monitor_setup_package_tabs('diagnostico');

$pkg = systemup_monitor_read_config();
$commands = systemup_monitor_local_commands();
$secret_masked = systemup_monitor_mask_secret($pkg['node_secret']);
$runtime = systemup_monitor_runtime_summary();
$selected_services = systemup_monitor_selected_service_labels($pkg);
$update_status = systemup_monitor_update_status($pkg);
$update_log_tail = '';
if (is_readable(SYSTEMUP_MONITOR_UPDATE_LOG_FILE)) {
    $lines = @file(SYSTEMUP_MONITOR_UPDATE_LOG_FILE, FILE_IGNORE_NEW_LINES);
    if (is_array($lines) && count($lines) > 0) {
        $update_log_tail = implode("\n", array_slice($lines, -20));
    }
}

include("head.inc");
?>
<body>
<?php include("fbegin.inc"); ?>
<?php if (isset($tab_array) && function_exists('display_top_tabs')): ?>
<?php foreach ($tab_array as $tab): ?>
<?php display_top_tabs($tab); ?>
<?php endforeach; ?>
<?php endif; ?>

<?php if (!empty($savemsg)): ?>
<div class="alert alert-info"><?=htmlspecialchars($savemsg)?></div>
<?php endif; ?>

<section class="panel panel-default">
  <div class="panel-heading">
    <h2 class="panel-title">Atualizacao do package</h2>
  </div>
  <div class="panel-body">
    <table class="table table-striped table-condensed">
      <tbody>
        <tr>
          <th>Versao instalada</th>
          <td><?=htmlspecialchars($update_status['installed_version'])?></td>
        </tr>
        <tr>
          <th>Versao no controlador</th>
          <td><?=htmlspecialchars($update_status['remote_version'] !== '' ? $update_status['remote_version'] : 'indisponivel')?></td>
        </tr>
        <tr>
          <th>Status</th>
          <td><?php
            if ($update_status['update_running']) {
                echo 'atualizacao em andamento';
            } elseif (!$update_status['check_ok']) {
                echo htmlspecialchars($update_status['check_error']);
            } elseif ($update_status['update_available']) {
                echo 'atualizacao disponivel';
            } else {
                echo 'em dia';
            }
          ?></td>
        </tr>
        <tr>
          <th>Log de atualizacao</th>
          <td><code><?=htmlspecialchars(SYSTEMUP_MONITOR_UPDATE_LOG_FILE)?></code></td>
        </tr>
      </tbody>
    </table>
    <?php if ($update_status['check_ok'] && $update_status['update_available'] && !$update_status['update_running']): ?>
    <form method="post" class="form-inline">
      <input type="hidden" name="action" value="package_update" />
      <button type="submit" class="btn btn-primary" onclick="return confirm('Atualizar o SystemUp Monitor para a versao <?=htmlspecialchars($update_status['remote_version'])?>?');">
        <i class="fa fa-refresh"></i> Atualizar package agora
      </button>
    </form>
    <?php endif; ?>
    <?php if ($update_log_tail !== ''): ?>
    <pre style="margin-top: 1rem; white-space: pre-wrap;"><?=htmlspecialchars($update_log_tail)?></pre>
    <?php endif; ?>
  </div>
</section>

<section class="panel panel-default">
  <div class="panel-heading">
    <h2 class="panel-title">SystemUp Monitor local diagnostics</h2>
  </div>
  <div class="panel-body">
    <table class="table table-striped table-condensed">
      <tbody>
        <tr>
          <th>Enabled</th>
          <td><?=htmlspecialchars($pkg['enabled'] == 'on' ? 'yes' : 'no')?></td>
        </tr>
        <tr>
          <th>Controller URL</th>
          <td><?=htmlspecialchars($pkg['controller_url'])?></td>
        </tr>
        <tr>
          <th>Node UID</th>
          <td><?=htmlspecialchars($pkg['node_uid'])?></td>
        </tr>
        <tr>
          <th>Customer code</th>
          <td><?=htmlspecialchars($pkg['customer_code'])?></td>
        </tr>
        <tr>
          <th>Heartbeat interval</th>
          <td><?=htmlspecialchars($pkg['interval_seconds'])?>s</td>
        </tr>
        <tr>
          <th>Heartbeat mode</th>
          <td><?=htmlspecialchars($runtime['heartbeat_mode'])?></td>
        </tr>
        <tr>
          <th>Versão do agente</th>
          <td><?=htmlspecialchars(defined('SYSTEMUP_MONITOR_AGENT_VERSION') ? SYSTEMUP_MONITOR_AGENT_VERSION : '0.2.0')?></td>
        </tr>
        <tr>
          <th>Selected services</th>
          <td><?=htmlspecialchars(empty($selected_services) ? 'none' : implode(', ', $selected_services))?></td>
        </tr>
        <tr>
          <th>Node secret</th>
          <td><?=htmlspecialchars($secret_masked)?></td>
        </tr>
        <tr>
          <th>Runtime enabled</th>
          <td><?=htmlspecialchars($runtime['enabled'] ? 'yes' : 'no')?></td>
        </tr>
        <tr>
          <th>Runtime config ready</th>
          <td><?=htmlspecialchars($runtime['config_ready'] ? 'yes' : 'no')?></td>
        </tr>
        <tr>
          <th>Runtime config file</th>
          <td><?=htmlspecialchars($runtime['config_file'])?><?= $runtime['config_exists'] ? ' (present)' : ' (missing)' ?></td>
        </tr>
        <tr>
          <th>Service status</th>
          <td><?=htmlspecialchars($runtime['service_status'])?></td>
        </tr>
      </tbody>
    </table>

    <?php if (!$runtime['config_ready']): ?>
    <div class="alert alert-warning" role="alert">
      Faltam campos obrigatorios para gerar o runtime do agente:
      <?=htmlspecialchars(implode(', ', $runtime['missing_fields']))?>
    </div>
    <?php endif; ?>

    <div style="margin-top: 1rem; padding-left: 1rem; padding-right: 1rem;">
      <h3 style="margin-top: 1.25rem; margin-bottom: 0.5rem;">Runtime paths</h3>
      <pre style="margin-top: 0.5rem; margin-bottom: 0; padding: 0.75rem;"><?php
echo htmlspecialchars("Agent: " . $runtime['agent_bin'] . "\n");
echo htmlspecialchars("Loop: " . $runtime['loop_bin'] . "\n");
echo htmlspecialchars("RC: " . $runtime['rc_script'] . "\n");
echo htmlspecialchars("Log: " . $runtime['log_file'] . "\n");
if (!empty($runtime['service_detail'])) {
    echo "\n" . htmlspecialchars($runtime['service_detail']);
}
?></pre>

      <h3 style="margin-top: 1.25rem; margin-bottom: 0.5rem;">Operational commands</h3>
      <pre style="margin-top: 0.5rem; margin-bottom: 1.25rem; padding: 0.75rem;"><?php foreach ($commands as $command) { echo htmlspecialchars($command) . "\n"; } ?></pre>
    </div>
  </div>
</section>
<?php include("foot.inc"); ?>
</body>
</html>
