<?php

require_once("guiconfig.inc");
require_once("/usr/local/pkg/systemup_monitor.inc");

systemup_monitor_setup_package_tabs('config');

include("head.inc");
?>
<body>
<?php include("fbegin.inc"); ?>
<?php if (isset($tab_array) && function_exists('display_top_tabs')): ?>
<?php foreach ($tab_array as $tab): ?>
<?php display_top_tabs($tab); ?>
<?php endforeach; ?>
<?php endif; ?>

<section class="panel panel-default">
  <div class="panel-heading">
    <h2 class="panel-title">Configuracao do agente</h2>
  </div>
  <div class="panel-body">
    <p class="text-muted" style="margin: 0 0 1em 0; font-size: 0.95rem; line-height: 1.45;">
      Campos do controlador, identidade do node e serviços monitorados. Use o botão abaixo para alterar URL, node UID, cliente, intervalo e serviços; salve no formulário para aplicar.
    </p>
    <div class="form-group" style="margin-top: 1.25rem; margin-bottom: 0;">
      <a href="pkg.php?xml=systemup_monitor.xml" class="btn btn-primary">
        <i class="fa-solid fa-list icon-embed-btn"></i>
        Ir para lista (Configuração)
      </a>
    </div>
  </div>
</section>
<?php include("foot.inc"); ?>
</body>
</html>
