<?php

require_once("guiconfig.inc");
require_once("/usr/local/pkg/systemup_monitor.inc");

systemup_monitor_setup_package_tabs('backup');

$pkg = systemup_monitor_read_config();
$savemsg = '';
$backup_result = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'save';

    if ($action === 'save') {
        $pkgref =& systemup_monitor_config_ref();
        $pkgref['config_backup_enabled'] = isset($_POST['config_backup_enabled']) ? 'on' : '';
        $pkgref['config_backup_interval_hours'] = trim((string) ($_POST['config_backup_interval_hours'] ?? '24'));
        $pkgref['config_backup_on_change'] = isset($_POST['config_backup_on_change']) ? 'on' : '';
        $pkgref['config_backup_compress'] = isset($_POST['config_backup_compress']) ? 'on' : '';
        $pkgref['config_backup_accept_remote_requests'] = isset($_POST['config_backup_accept_remote_requests']) ? 'on' : '';
        if ($pkgref['config_backup_interval_hours'] === '' || !ctype_digit($pkgref['config_backup_interval_hours'])) {
            $pkgref['config_backup_interval_hours'] = '24';
        }
        write_config('SystemUp Monitor backup settings updated');
        systemup_monitor_sync_config();
        $savemsg = 'Configurações de backup salvas e agente sincronizado.';
        $pkg = systemup_monitor_read_config();
    }

    if ($action === 'backup_now') {
        $result = systemup_monitor_run_backup_now();
        $backup_result = $result['output'];
        if ((int) $result['exit_code'] !== 0) {
            $savemsg = 'Falha ao enviar backup agora.';
        } else {
            $savemsg = 'Backup enviado ao controlador.';
        }
    }
}

$backup_summary = systemup_monitor_backup_summary();

include("head.inc");
?>
<body>
<?php include("fbegin.inc"); ?>
<?php if (isset($tab_array) && function_exists('display_top_tabs')): ?>
<?php foreach ($tab_array as $tab): ?>
<?php display_top_tabs($tab); ?>
<?php endforeach; ?>
<?php endif; ?>

<?php if ($savemsg !== ''): ?>
<div class="alert alert-info"><?=htmlspecialchars($savemsg)?></div>
<?php endif; ?>

<section class="panel panel-default">
  <div class="panel-heading">
    <h2 class="panel-title">Backup de configuração</h2>
  </div>
  <div class="panel-body">
    <p class="text-muted">
      Envia <code>/conf/config.xml</code> ao controlador Monitor-Pfsense com autenticação HMAC.
      O arquivo é criptografado no servidor; o XML não fica em texto puro no banco.
    </p>
    <form method="post" class="form-horizontal">
      <input type="hidden" name="action" value="save" />
      <div class="form-group">
        <label class="col-sm-3 control-label">Habilitar backup automático</label>
        <div class="col-sm-9">
          <div class="checkbox">
            <label>
              <input type="checkbox" name="config_backup_enabled" <?=($pkg['config_backup_enabled'] ?? '') === 'on' ? 'checked' : ''?> />
              Enviar backup conforme intervalo e regras abaixo
            </label>
          </div>
        </div>
      </div>
      <div class="form-group">
        <label class="col-sm-3 control-label">Intervalo (horas)</label>
        <div class="col-sm-9">
          <input type="number" min="1" max="168" class="form-control" name="config_backup_interval_hours"
            value="<?=htmlspecialchars($pkg['config_backup_interval_hours'] ?? '24')?>" style="max-width: 8em;" />
        </div>
      </div>
      <div class="form-group">
        <label class="col-sm-3 control-label">Somente se mudou</label>
        <div class="col-sm-9">
          <div class="checkbox">
            <label>
              <input type="checkbox" name="config_backup_on_change" <?=systemup_monitor_normalize_yes_no($pkg['config_backup_on_change'] ?? 'on', 'on') === 'on' ? 'checked' : ''?> />
              Entre intervalos, pular upload se o hash do XML não mudou
            </label>
          </div>
        </div>
      </div>
      <div class="form-group">
        <label class="col-sm-3 control-label">Compactar (gzip)</label>
        <div class="col-sm-9">
          <div class="checkbox">
            <label>
              <input type="checkbox" name="config_backup_compress" <?=systemup_monitor_normalize_yes_no($pkg['config_backup_compress'] ?? 'on', 'on') === 'on' ? 'checked' : ''?> />
              Enviar payload compactado
            </label>
          </div>
        </div>
      </div>
      <div class="form-group">
        <label class="col-sm-3 control-label">Aceitar solicitação remota</label>
        <div class="col-sm-9">
          <div class="checkbox">
            <label>
              <input type="checkbox" name="config_backup_accept_remote_requests" <?=systemup_monitor_normalize_yes_no($pkg['config_backup_accept_remote_requests'] ?? 'on', 'on') === 'on' ? 'checked' : ''?> />
              Executar <code>config_backup_now</code> recebido no heartbeat
            </label>
          </div>
        </div>
      </div>
      <div class="form-group">
        <div class="col-sm-offset-3 col-sm-9">
          <button type="submit" class="btn btn-primary">
            <i class="fa fa-save"></i> Salvar configurações
          </button>
        </div>
      </div>
    </form>
  </div>
</section>

<section class="panel panel-default">
  <div class="panel-heading">
    <h2 class="panel-title">Status local</h2>
  </div>
  <div class="panel-body">
    <table class="table table-striped table-condensed">
      <tbody>
        <tr>
          <th>Último envio</th>
          <td><?=htmlspecialchars($backup_summary['last_at'] !== '' ? $backup_summary['last_at'] : 'nunca')?></td>
        </tr>
        <tr>
          <th>Último SHA256</th>
          <td><code><?=htmlspecialchars($backup_summary['last_sha256'] !== '' ? $backup_summary['last_sha256'] : '—')?></code></td>
        </tr>
        <tr>
          <th>Último erro</th>
          <td><?=htmlspecialchars($backup_summary['last_error'] !== '' ? $backup_summary['last_error'] : '—')?></td>
        </tr>
        <tr>
          <th>Estado em</th>
          <td><code><?=htmlspecialchars($backup_summary['state_dir'])?></code></td>
        </tr>
      </tbody>
    </table>
    <form method="post" style="margin-top: 1rem;">
      <input type="hidden" name="action" value="backup_now" />
      <button type="submit" class="btn btn-success" onclick="return confirm('Enviar backup de configuração agora?');">
        <i class="fa fa-upload"></i> Enviar backup agora
      </button>
    </form>
    <?php if ($backup_result !== ''): ?>
    <pre class="text-muted" style="margin-top: 1rem; white-space: pre-wrap;"><?=htmlspecialchars($backup_result)?></pre>
    <?php endif; ?>
  </div>
</section>

<?php include("foot.inc"); ?>
