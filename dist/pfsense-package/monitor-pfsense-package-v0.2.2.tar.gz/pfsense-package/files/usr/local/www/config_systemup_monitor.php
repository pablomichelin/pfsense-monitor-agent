<?php

require_once("guiconfig.inc");
require_once("/usr/local/pkg/systemup_monitor.inc");

$page_title = array("Package", "Services: SystemUp Monitor", "Configuracao");

include("head.inc");
?>

<body>
<?php include("fbegin.inc"); ?>
<section class="panel panel-default">
  <div class="panel-heading">
    <h2 class="panel-title">Configuracao do agente</h2>
  </div>
  <div class="panel-body">
    <p class="text-muted" style="margin: 0 0 1rem 0; font-size: 0.9rem;">
      Campos do controlador, identidade do node e servicos monitorados. Edite abaixo para alterar URL, node UID, cliente, intervalo e servicos; salve para aplicar.
    </p>
    <a href="pkg_edit.php?xml=systemup_monitor.xml&amp;id=0" class="btn btn-primary">
      <i class="fa-solid fa-pen-to-square icon-embed-btn"></i>
      Editar configuracao
    </a>
  </div>
</section>
<?php include("foot.inc"); ?>
</body>
</html>
